
Práctica 14 - Arreglos y Matrices

Mauricio Riva Palacio Orozco

No. Cuenta 316666343

Para poder correr el programa se debe de abrir una terminal y ubicarse dentro de la carpeta rivapalacioomauricio14 e ingresar el comando ]$ ant run

Este programa hace las operaciones basicas con matrices(suma, resta, multiplicacion con otra matriz, multiplicacion con un escalar) se pueden modificar el valor de las matrices así como el escalar, para modificarlo abrir el archivo UsoMatriz2D y en el método main hay una lineas comentadas para poder modificar los valores de la matriz y el escalar.


