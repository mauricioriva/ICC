
Práctica 5 Euclides

Mauricio Riva Palacio Orozco
316666343

Este programa calcula el máximo común divisor(mcd) de 2 números usando el algoritmo de Euclides. En caso de no ingresar los números en el formato adecuado saldrán algunos ejemplos del mcd, como son parejas de números primos, números muy grandes, números chicos, el 1 dentro de la pareja de números, etc.

Lo que se tiene que ingresar en la terminal es: ant -Dargs="num1 num2" run , y tiene que estar ubicada la terminal en la carpeta rivapalacioomauricio05 en donde se encuentra un archivo build.xml .

Un ejemplo es ingresando:

	$ ant -Dargs="1190 476" run

Obtendras:

	compile:

	run:
     		[java] 
     		[java] El mcd de 1190 y 476 es: 238
     		[java] ------------
     		[java] 

