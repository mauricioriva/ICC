
Práctica 8 - Ajedrez

Mauricio Riva Palacio Orozco

No. Cuenta 316666343

Para poder correr el programa se debe de abrir una terminal y ubicarse dentro de la carpeta rivapalacioomauricio08 e ingresar el comando $ ant run	

Después saldrá un menú dentro de la terminal la cual dice te da la opcion de escoger una pieza: Reina, Caballo o Rey y dentro de cada una de estas piezas hay un submenu en el cual te dice la coordenada en la cual está la pieza; en este submenu puedes cambiar de posicion a la pieza dentro del tablero, a donde el usuario quiera; también una vez fijada la posicion de la pieza puedes saber todos sus movimientos posibles.

Nota: En esta versión 2.0 se corrigió el problema de los caracteres.
