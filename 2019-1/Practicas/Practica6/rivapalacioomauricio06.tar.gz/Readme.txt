
Práctica 6 - Tipos de datos y clases

Mauricio Riva Palacio Orozco 316666343

Para poder ejecutar esta tarea se necesita ubicarse en la terminal dentro de la carpeta rivapalacioomauricio.tar.gz en donde se encuentra el archivo build.xml; una vez dentro usando la herramienta ant ingresar:

	ant run_mosca

Para poder ver el programa en el que se canta la cancipon de la mosca alternando vocales de la letra original.
Para el siguiente ejercicio en el mismo lugar de la terminal ingresar:
	
	ant run_rfc

Este programa te da el RFC de personas, además de los datos para poder comprobarlo.

Actividad 6.2
De las comparaciones resultaria False, False, True debido a que las palabras no son las mismas literalmente inculyendo mayusculas y minysculas, el tercero el verdadero debido a que la función compare ignora todas esas características.


