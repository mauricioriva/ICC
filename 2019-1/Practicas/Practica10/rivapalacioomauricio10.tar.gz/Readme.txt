
Práctica 10 - Refactorización

Mauricio Riva Palacio Orozco

No. Cuenta 316666343

Para poder correr el programa se debe de abrir una terminal y ubicarse dentro de la carpeta rivapalacioomauricio10 e ingresar el comando $ ant run	

El programa te dira todo el registro de un contacto al escribir una parte de su nombre o una parte de su dirección o su telefono. El programa no cuenta con interacción con el usuario, si quieres realizar alguna consulta debes hacerlo desde un editor de texto abriendo el archivo UsoBaseDeDatosAgenda	en el método main.

La diferencia con la práctica 9 es que se hizo más general usando Object.
