
Práctica 7 - Contactos

Mauricio Riva Palacio Orozco

No. Cuenta 316666343

Para poder correr el programa se debe de abrir una terminal y ubicarse dentro de la carpeta rivapalacioomauricio07 e ingresar el comando $ ant run	

Después saldrá un menú dentro de la terminal la cual dice que se debe hacer para crear, buscar, mostrar todos los contactos o salir del programa.

1. Para poder buscar una cadena indicada en todos los contactos lo que hice fue, que primero me debo asegurar que la cadena no esté vacia y después uso el get de cada atributo y el comando "contains()" y dentro del parentesis se ingresa la cadena de busqueda, y así al ingresar por lo menos una de las letras del nombre o la direccion o un número, me devolverá el contacto o los contactos que contengan esa secuencia de letras o numeros, con todos los datos del contacto o los contactos, dependiendo del caso.

