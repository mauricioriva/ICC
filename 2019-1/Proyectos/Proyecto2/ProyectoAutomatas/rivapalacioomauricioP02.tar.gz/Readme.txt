
Proyecto 2 - Autómatas celulares bidimensionales

Mauricio Riva Palacio Orozco

No. Cuenta 316666343

Este programa se elaboró usando Java 10.

Para poder correr el programa debe de modificar el archivo build.xml en una de sus primeras lineas en donde se declara la ubicación del JAVA_HOME, cambiar por la dirección de su computadora en donde se encuentre instalado java, una vez hecho esto, se debe de abrir una terminal y ubicarse dentro de la carpeta rivapalacioomauricioP02 e ingresar el comando ]$ ant run

El unico módelo que incluye el proyecto es el de propagación de epidemias.
