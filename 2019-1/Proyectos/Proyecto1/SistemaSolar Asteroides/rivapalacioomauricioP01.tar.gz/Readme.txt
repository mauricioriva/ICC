
Proyecto 1 - Sistema Solar

Mauricio Riva Palacio Orozco

No. Cuenta 316666343

Este programa se elaboró usando Java 10.

Para poder correr el programa debe de modificar el archivo build.xml en una de sus primeras lineas en donde se declara la ubicación del JAVA_HOME, cambiar por la dirección de su computadora en donde se encuentre instalado java, una vez hecho esto, se debe de abrir una terminal y ubicarse dentro de la carpeta rivapalacioomauricioP01 e ingresar el comando ]$ ant run

Las texturas de los planetas se encuentran en src/imagenes.

El periodo orbital de los planetas es completamente ficticio, el planeta más alejado tarda 20 segundos aprox en dar una vuelta completa.

Comentario:
El planeta Plutón gira al lado contrario de los demás planetas para que se pueda diferenciar visualmente el ángulo de su orbita respecto a los demás planetas; debido a que el programa no está hecho a escala para que plutón se pudiera ver en la pantalla, ocasionalmente colisiona con otros planetas debido al cambio en su orbita respecto a los demás planetas.
